package com.dicoding.aristiyo.githubusers.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.aristiyo.githubusers.databinding.ActivityDetailUserBinding

class DetailUserActivity : AppCompatActivity() {

    private lateinit var mView: ActivityDetailUserBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mView = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(mView.root)
    }

    companion object {
        const val KEY_USERNAME = "key_username"
    }
}