package com.dicoding.aristiyo.githubusers.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.aristiyo.githubusers.models.SearchUsersResponse
import com.dicoding.aristiyo.githubusers.repository.online.ApiConfig
import kotlinx.coroutines.launch
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val _dataSearchUserResponse = MutableLiveData<SearchUsersResponse>()
    val dataSearchUsersResponse: LiveData<SearchUsersResponse> = _dataSearchUserResponse

    fun doGetSearchUser(hint: String) = viewModelScope.launch {
        val searchUser: Response<SearchUsersResponse> = ApiConfig.getApiService().getUsersSearch(hint)
        searchUser.run {
            if (this.isSuccessful) {
                _dataSearchUserResponse.value = this.body()
            }
        }
    }
}