package com.dicoding.aristiyo.githubusers.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.aristiyo.githubusers.databinding.UserAdapterItemBinding
import com.dicoding.aristiyo.githubusers.models.SearchUsersResponseItem

class UserAdapter(private val listUsers: ArrayList<SearchUsersResponseItem>): RecyclerView.Adapter<UserAdapter.AdapterHolders>() {

    private lateinit var   onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapterHolders {
        return AdapterHolders(
            UserAdapterItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false)
        )
    }

    override fun onBindViewHolder(holder: AdapterHolders, position: Int) {
        val (_, _, _, _, login, _, type, _, _, _, _, avatarUrl, _, _, _, _, _, _, _) = listUsers[position]
        Glide.with(holder.binding.root).load(avatarUrl).fitCenter().into(holder.binding.imgPhoto)
        holder.binding.txtUsername.text = login
        holder.binding.txtTypeStatus.text = type
        holder.binding.root.setOnClickListener {
            onItemClickCallback.onItemClicked(listUsers[holder.adapterPosition])
        }
    }

    override fun getItemCount(): Int = listUsers.size

    class AdapterHolders(var binding: UserAdapterItemBinding): RecyclerView.ViewHolder(binding.root)

    interface OnItemClickCallback {
        fun onItemClicked(data: SearchUsersResponseItem)
    }

    fun setData(items: List<SearchUsersResponseItem>) {
        listUsers.apply {
            clear()
            addAll(items)
        }
        notifyDataSetChanged()
    }
}