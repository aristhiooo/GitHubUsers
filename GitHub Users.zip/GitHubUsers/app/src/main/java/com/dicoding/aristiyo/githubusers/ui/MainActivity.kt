package com.dicoding.aristiyo.githubusers.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.aristiyo.githubusers.R
import com.dicoding.aristiyo.githubusers.databinding.ActivityMainBinding
import com.dicoding.aristiyo.githubusers.models.SearchUsersResponseItem
import com.dicoding.aristiyo.githubusers.ui.adapters.UserAdapter
import com.dicoding.aristiyo.githubusers.viewmodels.MainViewModel
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var mView: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mView = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mView.root)
        setSupportActionBar(mView.toolbarMain)
        supportActionBar?.title = ""

        mainViewModel.dataSearchUsersResponse.observe(this) { dataSet ->
            mView.recyclerView.apply {
                layoutManager = LinearLayoutManager(this@MainActivity)
                adapter = UserAdapter(arrayListOf()).apply{  setOnItemClickCallback(object : UserAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: SearchUsersResponseItem) {
                        Toast.makeText(applicationContext, "${data.login} dipilih", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@MainActivity, DetailUserActivity::class.java))
                    }
                })}.also { it.setData(dataSet.items) }
            }
        }

        mView.txtInputUsernameHint.editText?.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun afterTextChanged(p0: Editable?) {
                mainViewModel.doGetSearchUser(p0.toString())
            }

        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_options_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_favorite -> {
                Snackbar.make(mView.root, "Ke Halaman Daftar Favorite", Snackbar.LENGTH_SHORT).show()
            }
            R.id.menu_settings -> {
                Snackbar.make(mView.root, "Ke Halaman Settings", Snackbar.LENGTH_SHORT).show()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}